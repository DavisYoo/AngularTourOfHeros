import {BrowserModule} from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import {NgModule} from '@angular/core';
import {HttpClientModule} from '@angular/common/http';

import {AppComponent} from './app.component';
import {DashboardComponent} from './components/dashboard';
import {HeroesComponent} from './components/heroes';
import {HeroDetailComponent} from './components/hero-detail';
import {AppRoutingModule} from './app-routing.module';

import {HeroSearchComponent, MessagesComponent} from './components/common';


@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
  ],
  declarations: [
    AppComponent,
    DashboardComponent,
    HeroesComponent,
    HeroSearchComponent,
    MessagesComponent,
    HeroDetailComponent
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
