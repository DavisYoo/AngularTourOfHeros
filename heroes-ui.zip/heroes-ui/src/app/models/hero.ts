import {Page} from './pageable';

export class Hero {
  id: number;
  name: string;
}


export class Heroes extends Page<Hero> {
}
