// Spring Data Pageable

export class Sort {
  sorted?: boolean;
  unsorted?: boolean;
}


export class Pageable {
  offset?: number;
  page_number?: number;
  page_size?: number;
  paged?: boolean;
  sort?: Sort;
  sorted?: boolean;
  unsorted?: boolean;
  unpaged?: boolean;
}

// https://docs.spring.io/spring-data/commons/docs/current/api/org/springframework/data/domain/PageImpl.html
export class Page<T> {
  content?: Array<T>;
  first?: boolean;
  last?: boolean;
  number?: number;
  number_of_elements?: number;
  pageable?: Pageable;
  size?: number;
  sort?: Sort;
  total_elements?: number;
  total_pages?: number;
}
