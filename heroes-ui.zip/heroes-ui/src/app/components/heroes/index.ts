export * from './heroes.component';
