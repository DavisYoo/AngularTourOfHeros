export * from './hero-search.component';
