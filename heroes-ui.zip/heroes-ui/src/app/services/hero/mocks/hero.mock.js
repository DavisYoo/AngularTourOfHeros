var data = require('./hero.data.json');

module.exports = {
  '/api/v1/heroes': {
    get: (req, res) => {
      res.send(JSON.stringify(data.heros));
    },
    post: (req, res) => {
      let hero = req.body;
      hero.id = +data.heros.content[data.heros.length - 1].id + 1;
      data.heros.push(hero);

      res.send(JSON.stringify(hero));
    },
    put: (req, res) => {
      const hero = req.body;
      let index = data.heros.content.findIndex(hero => +hero.id === +req.body.id);

      if (hero && index > -1) {
        data.heros.content[index] = hero;
        res.send(JSON.stringify(hero));
      } else {
        res.send({});
      }
    }
  },
  '/api/v1/heroes/:id': {
    get: (req, res) => {
      let hero = findHeroById(req.params.id);

      res.send(hero ? JSON.stringify(hero) : {});
    },
    delete: (req, res) => {
      let hero = findHeroById(req.params.id);

      if (hero) {
        data.heros.content = data.heros.content.filter(hero => +hero.id != +req.body.id);
        res.send(JSON.stringify(hero));
      } else {
        res.send({});
      }

    }
  }
};

findHeroById = (id) => {
  id = id.toString();
  return data.heros.content.filter(hero => hero.id.toString() === id)[0];
};
