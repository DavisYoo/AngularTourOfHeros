# SS&C Starter UI Project

[![Developer Workspace](https://codenvy.io/factory/resources/codenvy-contribute.svg)](http://edit.dstcorp.net/f?id=factorya1s9lbgw0d0xu3ma)

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 7.3.9.
Also used this [Tour of Heroes](https://stackblitz.com/angular/xkyalvboyrj) example to model from. 

## Development server

Run `npm start` for a dev server (with mocks). The mocks are hosted by running a nodeJS server along side the Angular server.

Run `npm run start-api` for a dev server (using external api's). By default the api will route to `localhost:8080` but this can be configured in this file: `api.proxy.conf.json`.

Both of these methods will host `http://localhost:4200/` as the DNS. The app will automatically reload if you change any of the source files.

## Code scaffolding

Run `ng g component component-name` to generate a new component. You can also use `ng g directive|pipe|service|class|guard|interface|enum|module`.

## Build

Run `npm build` to build the project. The build produces a jar that will be stored in the `target/classes/META-INF/resources/webjars/` directory.

## Running unit tests

Run `npm test` to execute the unit tests via [Karma](https://karma-runner.github.io).

Run `npm run coverage` to execute the unit tests that produce a code coverage report.  Checks percentage of code being tested.

## Running lint checks

Run `npm lint` to execute the linting via [tsList](https://github.com/palantir/tslint).  Checks for styling and basic programming errors. 
