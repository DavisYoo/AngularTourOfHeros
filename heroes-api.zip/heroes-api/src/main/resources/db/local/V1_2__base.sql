INSERT INTO heroes (name)
    values ('Mr. Nice'),
           ('Narco'),
           ('Bombasto'),
           ('Celeritas'),
           ('Magneta'),
           ('RubberMan'),
           ('Dynama'),
           ('Dr IQ'),
           ('Magma'),
           ('Tornado');
