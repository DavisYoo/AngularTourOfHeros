File naming convetion of db base and init scripts?
