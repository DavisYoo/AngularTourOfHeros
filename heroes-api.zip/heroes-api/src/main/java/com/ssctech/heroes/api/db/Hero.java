package com.ssctech.heroes.api.db;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import com.ssctech.heroes.ApplicationConfig;
import com.ssctech.heroes.api.service.hero.HeroRepository;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * The Hero Domain Object.
 *
 * <p>
 * In JPA lingo, a Business/Domain Object is called an Entity.  An instance of an Entity roughly equates to a row in
 * the database. In this case, the {@code Hero} entity represents a row in the {@code heroes} table.
 *
 * <p>
 * Spring Data uses JPA annotations to provide the information needed for 'mapping' the Entity class to the database table,
 * and an associated {@code Repository} to manage the operations between the Entity and DB. <br/>
 * See also:<br/>
 * {@link HeroRepository}<br/>
 * {@link ApplicationConfig}</p>
 *
 * <p>
 * Lombok annotations are used to generate common boilerplate code - getters, setters, ToString, Equals and HashCode
 * methods. See <a href="https://projectlombok.org/">https://projectlombok.org/</a> for details.
 *
 * <p>
 * Swagger annotations are used to describe the Hero model.
 */

@Data
@ToString(callSuper = true)
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "heroes")
public class Hero extends BaseEntity
{
    public Hero() {
        super();
    }

    @ApiModelProperty(notes = "The name of the hero", required = true)
    @Column(name = "name", nullable = false)
    @NotNull
    private String name;
}
