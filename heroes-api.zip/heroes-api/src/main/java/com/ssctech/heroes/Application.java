package com.ssctech.heroes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.ApplicationPidFileWriter;

/**
 * The stater-api application.
 *
 * <p>
 * The goal of the <em>Starter Reference Application</em> is to provide a working example of the recommended
 * client (starter-static), server/service(s) (stater-api), and gateway (stater-edge) pattern for client/server development
 * at SS&C.  Tips, tricks, best practices and recommendations are provided in each project to make getting up to speed
 * as quick and painless as possible.  The reference application is based off of <a href="https://angular.io/tutorial">Angular's Tour of Heroes</a>,
 * but done the SS&C way.
 *
 * <p>
 * The purpose of the api component of the pattern is to handle requests form the client by providing a RESTful api.  The
 * <em>stater-api</em> reference project replaces the simulated data server used in Angular's tutorial and provides an example
 * of a working application server that handles the RESTful api responsible for the Hero CRUD operations (create, read, update, delete).
 * This is accomplished via Spring Data which also provides data pagination.
 */

@SpringBootApplication
@SuppressWarnings("checkstyle:hideutilityclassconstructor" /* Spring Boot requires default constructor on Application */)
public class Application
{
    public static void main(String[] args) {
        SpringApplication springApplication = new SpringApplication(Application.class);
        springApplication.addListeners(new ApplicationPidFileWriter());
        springApplication.run(args);
    }
}
