package com.ssctech.heroes;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.web.config.EnableSpringDataWebSupport;

/**
 * Spring Data "significantly reduces the amount of boilerplate code required to implement data access layers". In
 * Spring Data, the Entity class is managed by a   In Spring Data, the Entity class is managed by
 *
 * @see <a href="https://docs.spring.io/spring-data/jpa/docs/current/reference/html/">https://docs.spring.io/spring-data/jpa/docs/current/reference/html/</a>
 */
@Configuration
@EnableJpaRepositories
@EnableSpringDataWebSupport
public class ApplicationConfig
{
}
