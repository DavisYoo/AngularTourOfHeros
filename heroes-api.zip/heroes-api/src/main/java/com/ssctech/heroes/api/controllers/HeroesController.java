package com.ssctech.heroes.api.controllers;

import java.io.IOException;
import java.util.Optional;

import com.ssctech.heroes.api.exception.ApiException;
import com.ssctech.heroes.api.db.BaseEntity;
import com.ssctech.heroes.api.db.Hero;
import com.ssctech.heroes.api.service.hero.HeroesService;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import io.swagger.annotations.*;

/**
 * The heroes REST api.
 *
 * <p>
 * Controllers are a component of Spring MVC.  Typically, a controller is responsible for defining the REST endpoints it
 * will handle, then employees a {@code @Service} (in this case the {@link HeroesService}) to do the actual handling of the request.
 *
 * <p>
 * Swagger is used to document the REST API.<br/>
 * For more information: <br/>
 * <a herf="https://dzone.com/articles/spring-boot-restful-api-documentation-with-swagger">DZone Tutorial</a>
 * <a herf="https://swagger.io/">https://swagger.io/</a>
 *
 * <p>
 * BEST PRACTICE - do not provide a @RequestMapping at the class level.
 * <ul>
 * <li>Doing so makes versioning methods independently problematic in the future.
 * <li>Doing so can result in variable only @RequestMapping(s) at the method level (i.e. value = "/{id}").
 * This overrides Swagger's dispatcherServlet mapping of "/**" to ResourceHttpRequestHandler causing the Swagger UI to have errors.
 * </ul>
 */
@RestController
@Api(value = "heroes", description = "<em>CRUD</em> and <em>Pagination</em> operations for Heroes")
public class HeroesController
{

    @Autowired
    private HeroesService heroesService;

    @ApiOperation(value = "Retrieve a list of heroes, one page at a time, optionally where name contains a given value", position = 1)
    @ApiImplicitParams({
            @ApiImplicitParam(name = "page", dataType = "string", paramType = "query", value = "Results page you want to retrieve (0..N)"),
            @ApiImplicitParam(name = "size", dataType = "string", paramType = "query", value = "Number of records per page."),
            @ApiImplicitParam(name = "sort", allowMultiple = true, dataType = "string", paramType = "query",
                    value = "Sorting criteria in the format: property(,asc|desc). "
                            + "Default sort order is ascending. "
                            + "Multiple sort criteria are supported.")
    })
    @ApiResponses(value = {
            @ApiResponse(code = HttpStatus.SC_OK, message = "Successfully retrieved list"),
            @ApiResponse(code = HttpStatus.SC_BAD_REQUEST, message = "You are not authorized to view the resource"),
            @ApiResponse(code = HttpStatus.SC_FORBIDDEN, message = "Accessing the resource you were trying to reach is forbidden"),
            @ApiResponse(code = HttpStatus.SC_NOT_FOUND, message = "The resource you were trying to reach is not found")
    })
    @RequestMapping(value = "/api/v1/heroes", method = RequestMethod.GET, produces = "application/json")
    public Page<Hero> getHeroes(@ApiParam(value = "Name value (may be partial) to filter heroes by")
                                @RequestParam(value = "name", required = false) String term,
                                Pageable pageable) throws IOException {
        return Optional.of(heroesService.getHeroes(term, pageable)).orElseThrow(() -> new ApiException("Not Found"));
    }

    @ApiOperation(value = "Retrieve a Hero by ID", response = Hero.class, position = 2)
    @RequestMapping(value = "/api/v1/heroes/{id}", method = RequestMethod.GET, produces = "application/json")
    public Hero getHero(@ApiParam(value = "The id of the hero to return", required = true) @PathVariable("id") Hero hero) throws IOException {
        return heroesService.getHero(hero).orElseThrow(() -> new ApiException("Not Found"));
    }

    /**
     * Add hero to database.
     *
     * @param hero The hero to add
     * @return The added hero
     */
    @SuppressWarnings("checkstyle:MagicNumber")
    @ApiOperation(value = "Add a Hero", response = Hero.class, position = 3)
    @RequestMapping(value = "/api/v1/heroes", method = RequestMethod.POST, produces = "application/json")
    public Hero addHero(@ApiParam(value = "The hero to add to the db", required = true) @Validated(BaseEntity.Create.class) @RequestBody Hero hero) {
        Hero result = heroesService.addHero(hero);
        if (result == null) {
            throw new ApiException("Unable to add hero: " + hero);
        }

        return result;
    }

    /**
     * Update a hero in the database.
     *
     * @param hero The Hero to update
     * @return The updated Hero
     */
    @ApiOperation(value = "Update a Hero", response = Hero.class)
    @RequestMapping(value = "/api/v1/heroes", method = RequestMethod.PUT, produces = "application/json")
    public Hero updateHero(@ApiParam(value = "The hero to update in the db", required = true) @Validated(BaseEntity.Update.class) @RequestBody Hero hero) {
        Hero result = heroesService.updateHero(hero);
        if (result == null) {
            throw new ApiException("Unable to update hero: " + hero);
        }

        return result;
    }

    @ApiOperation(value = "Delete a Hero", response = Hero.class)
    @RequestMapping(value = "/api/v1/heroes/{id}", method = RequestMethod.DELETE, produces = "application/json")
    public void deleteHero(@ApiParam(value = "The ID of the hero to delete from db", required = true) @PathVariable("id") Hero hero) {
        heroesService.deleteHero(hero);
    }
}
