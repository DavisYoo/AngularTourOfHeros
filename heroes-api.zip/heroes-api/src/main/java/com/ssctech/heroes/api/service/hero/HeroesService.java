package com.ssctech.heroes.api.service.hero;

import java.util.Optional;

import com.ssctech.heroes.api.db.Hero;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

/**
 * Service handlers behind the heroes REST API.
 *
 * <p>
 * Services are a component of Spring MVC.  Typically, a controller is responsible for defining the REST endpoints it
 * will handle (in this case the {@link HeroesController}), then employees a service to do the actual handling of the request.

 */
@Service
public class HeroesService
{

    private static final int PAGE_SIZE = 2;

    @Autowired
    private HeroRepository heroRepository;

    private static final ExampleMatcher NAME_MATCHER = ExampleMatcher.matching().withMatcher("name", ExampleMatcher.GenericPropertyMatchers.ignoreCase());

    /**
     * Returns a list of heroes, optionally filtered by name.
     *
     * @param term A name (may be partial) to filter heroes by
     * @param pageable Spring Data provided Pageable object to support pagination of Heroes
     * @return
     */
    public Page<Hero> getHeroes(String term, Pageable pageable) {
        if (term != null) {
            return heroRepository.findByNameContains(term, pageable);
        } else {
            return heroRepository.findAll(pageable);
        }
    }

    public Optional<Hero> getHero(Hero hero) {
        return heroRepository.findById(hero.getId());
    }

    /**
     * Add a hero to the database.
     *
     * @param hero The Hero to add
     * @return
     */
    public Hero addHero(Hero hero) {
        Example<Hero> example = Example.of(hero, NAME_MATCHER);
        if (!heroRepository.exists(example)) {
            return heroRepository.save(hero);
        }

        return null;
    }

    /**
     * Update a Hero in the database.
     *
     * @param hero The Hero to update
     * @return
     */
    public Hero updateHero(Hero hero) {
        Optional<Hero> existingHero = heroRepository.findById(hero.getId());
        if (existingHero.isPresent()) {
            hero.setId(existingHero.get().getId());
            return heroRepository.save(hero);
        }

        return null;
    }

    /**
     * Delete a Hero from the database.
     *
     * @param hero The Hero to be deleted
     * @return
     */
    public Hero deleteHero(Hero hero) {
        Optional<Hero> existingHero = heroRepository.findById(hero.getId());
        if (existingHero.isPresent()) {
            Hero deleteHero = existingHero.get();
            heroRepository.delete(deleteHero);
            return deleteHero;
        }

        return null;
    }
}
