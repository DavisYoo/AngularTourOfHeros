package com.ssctech.heroes.api.controllers;

import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

/**
 * RESTful API Exception handler.
 */
@RestControllerAdvice
public class WebRestControllerAdvice extends ResponseEntityExceptionHandler
{

}
