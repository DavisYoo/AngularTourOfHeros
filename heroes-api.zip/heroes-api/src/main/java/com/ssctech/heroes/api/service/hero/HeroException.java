package com.ssctech.heroes.api.service.hero;

public class HeroException extends Exception {
    public HeroException (String message) { super(message); }
}
