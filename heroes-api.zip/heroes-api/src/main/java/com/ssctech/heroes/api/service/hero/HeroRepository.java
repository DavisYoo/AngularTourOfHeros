package com.ssctech.heroes.api.service.hero;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.ssctech.heroes.api.db.Hero;

/**
 * The HeroRepository manages the operations of {@link Hero} Entities.
 *
 * <p>
 * The {@code Repository} interface is a key component of Spring Data.  At runtime, Spring Data provides a proxy instance
 * that satisfies the interface declaration.  Extending from {@code JpaRepository} ensures the proxy provides both
 * sophisticated CRUD functionality and simplified pagination.  The proxy can also provide custom queries using Spring Data's
 * query builder mechanism that is able to build entity specific queries from method names.<br/>
 *
 * <p>
 * See also: <br/>
 * <a href="https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#repositories">https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#repositories</a><br/>
 * <a href="https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#jpa.repositories">https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#jpa.repositories</a><br/>
 * <a href="https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#repositories.query-methods.details">https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#repositories.query-methods.details</a><br/>
 */
public interface HeroRepository extends JpaRepository<Hero, Integer>
{
    Optional<Hero> findById(Integer id);

    Page<Hero> findByNameContains(String term, Pageable pageable);
}
