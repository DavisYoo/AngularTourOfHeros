package com.ssctech.heroes.api.db;

import java.util.Date;
import javax.persistence.*;

import org.hibernate.annotations.Generated;
import org.hibernate.annotations.GenerationTime;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;


/**
 * The abstract base domain object.
 *
 * <p>
 * In JPA lingo, a Business/Domain Object is called an Entity.  An instance of an Entity roughly equates to a row in
 * the database. This abstract base class captures common elements of our database design by handling the internal and
 * external ids and created and modified timestamps.
 *
 * <p>
 * Spring Data uses JPA annotations to provide the information needed for 'mapping' the Entity class to the database table.
 * In the case of base classes like this, the use of the {@code @MappedSuperclass} annotation tells Spring Data/JPA to
 * apply the information provide in the other JPA annotations in this class to the classes that derive from this base.
 *
 * <p>
 * Jackson annotations are used to suppress and map data between instances of derived objects and JSON strings when
 * sending and receiving entities through RESTful interfaces provided by Spring MVC's {@code @Controller}'s and {@code @Service}'s.
 *
 * <p>
 * Lombok annotations are used to generate common boilerplate code - getters, setters, ToString, Equals and HashCode
 * methods. See <a href="https://projectlombok.org/">https://projectlombok.org/</a> for details.
 *
 * <p>
 * Swagger annotations are used to describe the base model.
 */
@Data
@ToString
@EqualsAndHashCode
@MappedSuperclass
public abstract class BaseEntity
{
    /**
     * Spring MVC validation group - marker for validations to apply during creation.
     */
    public interface Create
    {
    }

    /**
     * Spring MVC validation group - marker for validations to apply during updates.
     */
    public interface Update
    {
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @ApiModelProperty(notes = "The database generated hero ID", readOnly = true)
    @Column(name = "id", nullable = false, unique = true)
    private Integer id;

    @Generated(GenerationTime.INSERT)
    @Temporal(TemporalType.TIMESTAMP)
    @ApiModelProperty(notes = "The database generated timestamp when hero is first created", readOnly = true)
    @Column(name = "date_created", insertable = false, updatable = false)
    private Date dateCreate;

    @Generated(GenerationTime.ALWAYS)
    @Temporal(TemporalType.TIMESTAMP)
    @ApiModelProperty(notes = "The database generated timestamp each time the hero is updated", readOnly = true)
    @Column(name = "date_modified", insertable = false, updatable = false)
    private Date dateModified;

    public Date getDateCreate() {
        return (dateCreate != null) ? new Date(dateCreate.getTime()) : null;
    }

    public void setDateCreate(Date dateCreate) {
        this.dateCreate = new Date(dateCreate.getTime());
    }

    public Date getDateModified() {
        return (dateModified != null) ? new Date(dateModified.getTime()) : null;
    }

    public void setDateModified(Date dateModified) {
        this.dateModified = new Date(dateModified.getTime());
    }
}
