## SS&C Starter API Project

### Project Setup

### Application Configuration
1. Navigate to src\main\resources
2. Copy the contents of the application-local.yml.default
3. Create a new file in the resources folder called application-local.yml and paste the contents from the previous file

#### Heroes Database
1. This project requires a database.  It can be anything - a local MySQL instance, an in-memory H2, or something running on server.  The reference app was developed using a local instance of MySQL
2. Whatever database you're using, create a database with a meaningful name - may we suggest a name of `ssc-heroes`
3. Update application-local.yml with the correct jdbc connection string to point your `ssc-heroes` database.
4. FlyWay will run the scripts in `./src/main/resources/db/*/*.sql` to set everything up

**NOTE**: When cloning this project to get started on a project of your own, you will need to delete and recreate the database
      as you edit your initializations scripts.  FlyWay will remind you with errors when spinning up the server if you haven't
      done so already.

#### IntelliJ Setup
<details><summary>click here...</summary><p>

<h5>To Install Lombok Plugin on IntelliJ</h5>
<ol>
    <li>In IntelliJ, go to File and then Settings
    <li>On the side of the settings window, go to plugins
    <li>Search "Lombok"
    <li>Click install
</ol>

<h5>Running Application</h5>
<ol>
    <li>Navigate to src\main\java\com\ssctech\heroes\Application.java
    <li>Click the green play button next to the main() method

From now on, a green play button will be at the top of your IDE that allows you to run the application.
</p></details>
