## Working with Spring Data JPA

We make use of Spring Data, which is built on JPA, to communicate from Java to our MySQL database.
The pattern we follow is that pretty much all code that falls under a package that includes `jpa` in the name, such as `com.ssctech.heroes.api.jpa`, is code that relies on, extends from, or otherwise is connected to Spring Data.
To learn more about working with Spring Data, read the [Spring Data JPA - Reference Documentation]( https://docs.spring.io/spring-data/jpa/docs/current/reference/html/).
Keep in mind that when the docs show the use of annotations and XML to configure Spring, our project uses annotations when available (see ApplicationConfig.java),
but rather than XML we use YAML (see application.yml).  You shouldn’t need to tweak any of the configuration, everything needed to run should already be in place.

**NOTE:** After cloning this starter project, you’ll want to be sure and refactor and rename `heroes` in the package name to something more meaningful to your project.

#### Highlights:

- [Working with Spring Data Repositories](https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#repositories)  
  A lot of the magic Spring Data provides is via the Query Methods provided by Repositories.  Therefore, this section is a good read just to get a good understanding of what repositories provides us.
  When the docs mention various interfaces know that we make use of the `JpaRepository` interface, which extends both the `CrudRepository` and `PagingAndSortingRepository`, 
  providing us the benefit of both. 
- [Query Creation](https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#repositories.query-methods.query-creation)  
  This section covers the naming conventions when _"deriving the query form the method name directly"_.  I've found the information here can be very subtle, and it's importance not clear after
  the first read.  
  - This one sentence _"However, the first `By` acts as delimiter to indicate the start of the actual criteria."_ was important in working out how to query for all
   distinct values.  This leads to method names like `findAllDistinctBy` or `findAllDistinctByOrderBy<<column name here>>` where the first `By` may read funny because it's not followed by a column name,
   but is simply standing in as the delimiter that triggers the proper parsing.
  - The section on [Property Expressions](https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#repositories.query-methods.query-property-expressions) explains how `_` is used in method names.
   It is optional, but manually defines traversal points when working with nested data.  Taking a method named `findFundsByFundSponsor_SystemIdInAndFundSponsor_FundSponsorIdInAndId_EffEndTsAndMfStatusCdOrderById_FundCode`
   as an example, we can determine that `Id` and `FundSponsor` in this query represent data structures of their own (a composite key and joined table respectively).  And we can further determine that
   the `FundSponsor` object contains both `SystemId` and `FundSponsorId` properties, and that `Id` contains both `EffEndTs` and `FundCode`.
- [JPA Repositories](https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#jpa.repositories) Has a few thingw worth noting...
  - Under [Query Creation](https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#jpa.query-methods.query-creation), there is a table of keywords you can use in method names.
  - [Using `@Query`](https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#jpa.query-methods.at-query) to define SQL statements rather than use nameing convention.
  - [Projections](https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#projections) - useful when you want to return results less than `SELECT *`   
- [Appendix C: Repository query keywords](https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#repository-query-keywords)
