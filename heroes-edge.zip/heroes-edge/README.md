# Tour Of Heroes - Edge

This is a Java 11, Spring Boot 2, Maven project. See [project documentation](https://code.ssnc.global/common-reference/angular/heroes/project) for more details.

